Fighterpilot for Unity
======================

--> Brady O'Leary 2017

You are a Pilot, guiding your ship through the depths of space fighting off waves of enemies.
How long will you last?

Made originally for the Global Game Jam, but the original version vas very broken.

Also, check out the Carolina Gamers' Club. We develop games and do cool stuff!